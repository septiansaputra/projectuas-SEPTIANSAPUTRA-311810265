<?php
 
session_start();
 
if (empty($_SESSION['username'])){
 
    header('location:login.php');
}
else
{
?>

<!DOCTYPE html>
<html>
<head>
	<title>Kelompok</title>
	<?php include 'template/css.php';?>
</head>
<body>

<?php
	include"koneksi.php";
	$no = 1;
	$data = mysqli_query ($koneksi, " select 
											id_pelanggan,
											nama_pelanggan,
											alamat_pelanggan,
											nohp,
											status,
											nik
											
											
									  from 
									  pelanggan
									  where id_pelanggan = $_GET[id]");
	$row = mysqli_fetch_array ($data);
	
?>

<div class="container" style="margin-top:2%">
	<div class="row">
                            <div class="sparkline12-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-5 col-sm-5 col-xs-5">
                                            <div class="all-form-element-inner">
                                               	 
			<form class="form-horizontal" action="a_update.php" method="post">

				<div class="box-body">
					<div class="form-group">
						<label for="inputEmail3" class="col-sm-3 control-label">nama_pelanggan</label>
						 <input type="hidden" name="id_pelanggan" value="<?php echo $row['id_pelanggan'] ; ?>">
						<div class="col-sm-4">
							<input type="text" name="nama_pelanggan" class="form-control"  value="<?php echo $row['nama_pelanggan'] ; ?>" >
						</div>
					</div>

					<div class="form-group">
						<label for="inputPassword3" class="col-sm-3 control-label">alamat_pelanggan</label>

						<div class="col-sm-4">
							<input type="text" name="alamat_pelanggan" class="form-control" id="inputPassword3" placeholder="alamat_pelanggan"  value="<?php echo $row['alamat_pelanggan'] ; ?>">
						</div>
					</div>


					<div class="form-group">
						<label for="text" class="col-sm-3 control-label">NOHP</label>

						<div class="col-sm-4">
							<input type="text" name="nohp" class="form-control" placeholder="nohp"  value="<?php echo $row['nohp'] ; ?>" autofocus>
						</div>
					</div>
					<div class="form-group">
						<label for="dep" class="col-sm-3 control-label">Status</label>

						<div class="col-sm-4">
							<input type="text" name="status" class="form-control" placeholder="status"  value="<?php echo $row['status'] ; ?>" autofocus>
						</div>
					</div>

					<div class="form-group">
						<label for="dep" class="col-sm-3 control-label">NIK</label>

						<div class="col-sm-4">
							<input type="text" name="nik" class="form-control" placeholder="nik"  value="<?php echo $row['nik'] ; ?>" autofocus>
						</div>
					</div>



						
					

					



					</div>
				</div>
				<div class="form-group-inner">
                <div class="login-btn-inner">
                        <div class="row">

                                <div class="col-lg-3"></div>
                                     <div class="col-lg-9">

                                             <div class="login-horizental cancel-wp pull-left form-bc-ele">      

                                                     <button class="btn btn-sm btn-primary login-submit-cs" type="submit">Simpan</button>
                                              </div>
                                            
                                        </div>
                                </div>

                        </div>
                        </div>
				
			</form>
		</div>
	</div>
<?php
}
?>
</body>
</html>



           








