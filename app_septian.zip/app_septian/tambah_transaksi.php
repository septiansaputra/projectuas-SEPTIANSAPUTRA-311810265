

<!DOCTYPE html>
<html>
<head>
	<title>Transaksi</title>
	<?php include 'template/css.php';?>
</head>
<body>
	
<div class="container" style="margin-top:2%">
	<div class="row">
                            <div class="sparkline12-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-5 col-sm-5 col-xs-5">
                                            <div class="all-form-element-inner">
                                               	 
			<form class="form-horizontal" action="a_transaksi.php" method="post">
				<div class="box-body">
					<div class="form-group">
						<label for="inputEmail3" class="col-sm-3 control-label">Nomor Transaksi</label>

						<div class="col-sm-4">
							<input type="text" name="nomor_transaksi" class="form-control" placeholder="Nomor Transaksi" autofocus>
						</div>
					</div>

					<div class="form-group">
						<label for="inputPassword3" class="col-sm-3 control-label">Tanggal Transaksi</label>

						<div class="col-sm-4">
							<input type="date" name="tanggal_transaksi" class="form-control" id="inputPassword3" placeholder="Tanggal Transaksi">
						</div>
					</div>

					<div class="form-group">
						<label for="dep" class="col-sm-3 control-label">Nama Pelanggan</label>
					<div class="col-sm-4">
						<select id="form_prov"  class="form-control" name="id_pelanggan">
							<option value="">Pilih Pelanggan</option>
							<?php 
							include"koneksi.php";
							$pelanggan = mysqli_query($koneksi,"SELECT id_pelanggan,nama_pelanggan FROM pelanggan ORDER BY id_pelanggan");
							while($d = mysqli_fetch_array($pelanggan)){
								?>
								<option value="<?php echo $d['id_pelanggan']; ?>"><?php echo $d['nama_pelanggan']; ?></option>
								<?php 
							}
							?>
						</select>
					</div>
				</div>
			</div>

								<div class="form-group">
						<label for="dep" class="col-sm-3 control-label">Nama Produk</label>
					<div class="col-sm-4">
						<select id="form_prov"  class="form-control" name="id_produk">
							<option value="">Pilih Produk</option>
							<?php 
							include"koneksi.php";
							$produk = mysqli_query($koneksi,"SELECT id_produk,nama_produk FROM produk ORDER BY id_produk");
							while($d = mysqli_fetch_array($produk)){
								?>
								<option value="<?php echo $d['id_produk']; ?>"><?php echo $d['nama_produk']; ?></option>
								<?php 
							}
							?>
						</select>
					</div>
				</div>
			</div>





				<div class="form-group-inner">
                <div class="login-btn-inner">
                        <div class="row">


                                <div class="col-lg-3">
                                	
                                </div>

                                     <div class="col-lg-9">

                                             <div class="login-horizental cancel-wp pull-left form-bc-ele">      
                                                     <button class="btn btn-sm btn-primary login-submit-cs" type="submit">Simpan</button>
                                              </div>
                                            
                                        </div>
                                </div>


                               

                        </div>
                        </div>
				
			</form>
		</div>
	</div>

</body>
</html>



           