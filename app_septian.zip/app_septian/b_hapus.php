<?php
include"koneksi.php";


$query = "DELETE FROM produk
							WHERE id_produk ='$_GET[id]'
								";

mysqli_query($koneksi, $query)
or die ("Gagal Perintah SQL".mysql_error());
header('location:data_produk.php');

?>

