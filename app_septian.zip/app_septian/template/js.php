


        <div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copy-right">
                            <p> <a href="">E-Document Build 2019 </a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

