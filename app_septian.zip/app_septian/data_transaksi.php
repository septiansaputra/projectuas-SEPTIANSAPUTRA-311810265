<?php
 
session_start();
 
if (empty($_SESSION['username'])){
 
    header('location:login.php');
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
	<title>Transaksi</title>
	<?php include 'template/css.php';?>
</head>
<body>
<div class="container" style="margin-top:2%">
	<div class="row">

	
<div class="col-md-12 col-md-offset-1">
  <div class="data-table-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline13-list">
                            <div class="sparkline13-hd">
                                <div class="main-sparkline13-hd">
                                    <h1>User <span class="table-project-n" style="font-style:arial;">Data</span> Table</h1>
                                    <a class="btn btn-primary" href="tambah_transaksi.php">Tambah</a>
                                </div>
                            </div>
                            
                            <div class="sparkline13-graph">

                                <div class="datatable-dashv1-list custom-datatable-overright">
								
								<table id="table" data-toggle="table" data-pagination="true" data-search="true"  data-click-to-select="true" data-toolbar="#toolbar">
                                        <thead>
                                            <tr>
                                             
                                                <th data-field="nomor_transaksi">No Transaksi</th>
                                                <th data-field="tanggal_transaksi" data-editable="true">Tanggal Transaksi</th>
                                     
                                                <th></th>
                                            </tr>

                                            </thead>

                                            <?php
						include"koneksi.php";
						$no = 1;
						$data = mysqli_query ($koneksi, " select 
                                                                
																nomor_transaksi,
																tanggal_transaksi

																
														  from 
														  transaksi
														  order by id_transaksi DESC");
						while ($row = mysqli_fetch_array ($data))
						{
					?>

                                        
                                        
                                            <tr>
                                                <td><?php echo $row['nomor_transaksi']; ?></td>
                                                <td><?php echo $row['tanggal_transaksi']; ?></td>
                                                <td>
	
                                              
                                                </td>
                                            </tr>
                              
                                           
                              
                                      
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>

<?php
}
?>

</table>

<?php include 'template/js.php';?>

<?php
}
?>
</body>
</html>