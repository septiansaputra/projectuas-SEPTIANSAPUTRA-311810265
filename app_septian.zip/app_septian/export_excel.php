<!DOCTYPE html>
<html>
<head>
	<title>Kelompok</title>
</head>
<body>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;

	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>

	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data Transaksi.xls");
	?>

	<center>
		<h1>Laporan  </h1>
	</center>

	<table border="1">


		<tr>
			<th data-field="id">No</th>
                                                <th data-field="nama_pelanggan" >Nama Pelanggan</th>
                                                <th data-field="alamat_pelanggan" >Alamat</th>
                                                <th data-field="nama_produk" >Nama Produk</th>
                                                <th data-field="harga_produk" >Harga Produk</th>
                                                <th data-field="nomor_transaksi" >Nomor Transaksi</th>
                                                <th data-field="tanggal_transaksi" >Tanggal Transaksi</th>
		</tr>
		<?php 
		// koneksi database
		$koneksi = mysqli_connect("localhost","root","","septian_saputra_311810265");

		// menampilkan data pegawai
		$data = mysqli_query($koneksi," select 
                             p.id_pelanggan,
                             p.nama_pelanggan,
                             p.alamat_pelanggan,

                             b.id_produk,
                             b.nama_produk,
                             b.harga_produk,

                            c.id_transaksi,
                            c.id_pelanggan,
                            c.id_produk,
                             c.nomor_transaksi,
                             c.tanggal_transaksi
                    
                            from pelanggan p INNER JOIN transaksi c ON p.id_pelanggan=c.id_pelanggan
                            inner join produk b on c.id_produk=b.id_produk
                            order by c.id_transaksi DESC ");
		$no = 1;
		while($row = mysqli_fetch_array($data)){
		?>
		<tr>
			<td><?php echo $no++; ?></td>  
                                         <td><?php echo $row['nama_pelanggan']; ?></td>
                                         <td><?php echo $row['alamat_pelanggan']; ?></td>
                                         <td><?php echo $row['nama_produk']; ?></td>
                                         <td><?php echo $row['harga_produk']; ?></td>
                                         <td><?php echo $row['nomor_transaksi']; ?></td>
                                         <td><?php echo $row['tanggal_transaksi']; ?></td>
		</tr>
		<?php 
		}
		?>
	</table>
</body>
</html>