

<!DOCTYPE html>
<html>
<head>
	<title>Pelanggan</title>
	<?php include 'template/css.php';?>
</head>
<body>
	
<div class="container" style="margin-top:2%">
	<div class="row">
                            <div class="sparkline12-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-5 col-sm-5 col-xs-5">
                                            <div class="all-form-element-inner">
                                               	 
			<form class="form-horizontal" action="a_pelanggan.php" method="post">
				<div class="box-body">
					<div class="form-group">
						<label for="inputEmail3" class="col-sm-3 control-label">Nama Pelanggan</label>

						<div class="col-sm-4">
							<input type="text" name="nama_pelanggan" class="form-control" placeholder="Nama Pelanggan" autofocus>
						</div>
					</div>

					<div class="form-group">
						<label for="inputPassword3" class="col-sm-3 control-label">Alamat Pelanggan</label>

						<div class="col-sm-4">
							<input type="text" name="alamat_pelanggan" class="form-control" id="inputPassword3" placeholder="Alamat Pelanggan">
						</div>
					</div>


					<div class="form-group">
						<label for="text" class="col-sm-3 control-label">No HP</label>

						<div class="col-sm-4">
							<input type="text" name="nohp" class="form-control" placeholder="No Hp" autofocus>
						</div>
					</div>
					<div class="form-group">
						<label for="dep" class="col-sm-3 control-label">Status</label>

						<div class="col-sm-4">
							<input type="text" name="status" class="form-control" placeholder="Status" autofocus>
						</div>
					</div>

					<div class="form-group">
						<label for="dep" class="col-sm-3 control-label">NIK</label>

						<div class="col-sm-4">
							<input type="text" name="nik" class="form-control" placeholder="Nik" autofocus>
						</div>
					</div>

				</div>


				<div class="form-group-inner">
                <div class="login-btn-inner">
                        <div class="row">


                                <div class="col-lg-3">
                                	
                                </div>

                                     <div class="col-lg-9">

                                             <div class="login-horizental cancel-wp pull-left form-bc-ele">      
                                                     <button class="btn btn-sm btn-primary login-submit-cs" type="submit">Simpan</button>
                                              </div>
                                            
                                        </div>
                                </div>


                               

                        </div>
                        </div>
				
			</form>
		</div>
	</div>

</body>
</html>



           