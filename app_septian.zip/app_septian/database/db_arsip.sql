-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 31 Okt 2019 pada 03.25
-- Versi Server: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_arsip`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `arsip`
--

CREATE TABLE `arsip` (
  `id_berkas` int(10) NOT NULL,
  `id_user` int(50) NOT NULL,
  `kk` varchar(30) NOT NULL,
  `ktp` varchar(30) NOT NULL,
  `npwp` varchar(30) NOT NULL,
  `bpjs` varchar(30) NOT NULL,
  `ijazah` varchar(30) NOT NULL,
  `tanggal` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `arsip`
--

INSERT INTO `arsip` (`id_berkas`, `id_user`, `kk`, `ktp`, `npwp`, `bpjs`, `ijazah`, `tanggal`) VALUES
(79, 0, '', '', '', '', '', ''),
(84, 0, '', '', '', '', '', ''),
(100057, 0, '', '', '', '', '', '2019-10-19'),
(100058, 0, '', '', 'senpai - Copy (4).pdf', '', '', '2019-10-12'),
(100059, 0, '', 'arumku.pdf', '', '', '', '2019-10-26'),
(100061, 0, '', 'arumku.pdf', '', '', '', '2019-10-19'),
(100062, 0, '', 'arumku.pdf', '', '', '', '2019-10-13'),
(100064, 0, '', 'arumku.pdf', '', '', '', '2019-10-26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(50) NOT NULL,
  `username` text COLLATE latin1_general_ci NOT NULL,
  `password` text COLLATE latin1_general_ci NOT NULL,
  `nik` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `dept` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `level` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `telephone` varchar(30) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `nik`, `dept`, `level`, `telephone`) VALUES
(100058, 'user', 'user', '2', 'Purchasing', 'user', '085714308855'),
(100057, 'admin', 'admin', '1', 'IT', 'admin', '085714308855');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `arsip`
--
ALTER TABLE `arsip`
  ADD PRIMARY KEY (`id_berkas`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `arsip`
--
ALTER TABLE `arsip`
  MODIFY `id_berkas` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100068;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100060;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
