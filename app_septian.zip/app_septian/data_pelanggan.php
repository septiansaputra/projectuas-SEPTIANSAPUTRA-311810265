<?php
 
session_start();
 
if (empty($_SESSION['username'])){
 
    header('location:login.php');
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
	<title>Pelanggan</title>
	<?php include 'template/css.php';?>
</head>
<body>
<div class="container" style="margin-top:2%">
	<div class="row">

	
<div class="col-md-12 col-md-offset-1">
  <div class="data-table-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline13-list">
                            <div class="sparkline13-hd">
                                <div class="main-sparkline13-hd">
                                    <h1>User <span class="table-project-n" style="font-style:arial;">Data</span> Table</h1>
                                    <a class="btn btn-primary" href="tambah_pelanggan.php">Tambah</a>
                                </div>
                            </div>
                            
                            <div class="sparkline13-graph">

                                <div class="datatable-dashv1-list custom-datatable-overright">
								
								<table id="table" data-toggle="table" data-pagination="true" data-search="true"  data-click-to-select="true" data-toolbar="#toolbar">
                                        <thead>
                                            <tr>
                                             
                                                <th data-field="id_pelanggan">Id Pelanggan</th>
                                                <th data-field="nama_pelanggan" data-editable="true">Nama</th>
                                                <th data-field="alamat_pelanggan" data-editable="true">Alamat</th>
                                                <th data-field="nohp" data-editable="true">No HP</th>
                                                <th data-field="status" data-editable="true">Status</th>
                                                <th data-field="nik" data-editable="true">NIK</th>
                                                <th data-field="action">Action</th>
                                            </tr>

                                            </thead>

                                            <?php
						include"koneksi.php";
						$no = 1;
						$data = mysqli_query ($koneksi, " select 
																id_pelanggan,
																nama_pelanggan,
																alamat_pelanggan,
                                                                nohp,
                                                                status,
                                                                nik
													
																
														  from 
														  pelanggan 
														  order by id_pelanggan DESC");
						while ($row = mysqli_fetch_array ($data))
						{
					?>

                                        
                                        
                                            <tr>
                                               
                                                <td><?php echo $no++; ?></td>
                                                <td><?php echo $row['nama_pelanggan']; ?></td>
                                                <td><?php echo $row['alamat_pelanggan']; ?></td>
                                                <td><?php echo $row['nohp']; ?></td>
                                                <td><?php echo $row['status']; ?></td>
                                                <td><?php echo $row['nik']; ?></td>
                                         
                                                <td >


                                                <button><a href="a_edit.php?id=<?php echo $row['id_pelanggan']; ?>"><i class="fa fa-book"></i> Edit</a></button> 
						                        <button><a href="a_hapus.php?id=<?php echo $row['id_pelanggan']; ?>"><i class="fa fa-recycle"></i>Hapus</a></button>
                                              
                                                </td>
                                            </tr>
                              
                                           
                              
                                      
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>

<?php
}
?>

</table>

<?php include 'template/js.php';?>

<?php
}
?>
</body>
</html>