<?php
include"koneksi.php";

$nomor_transaksi = $_POST['nomor_transaksi'];
$tanggal_transaksi = $_POST['tanggal_transaksi'];
$id_produk = $_POST['id_produk'];
$id_pelanggan = $_POST['id_pelanggan'];



$query = "insert INTO transaksi SET
							nomor_transaksi = '$nomor_transaksi',
							tanggal_transaksi = '$tanggal_transaksi',
							id_produk = '$id_produk',
							id_pelanggan = '$id_pelanggan'
							";

print_r($query);
mysqli_query($koneksi, $query)
or die ("Gagal Perintah SQL".mysql_error());
header('location:data_transaksi.php');
	
?>

