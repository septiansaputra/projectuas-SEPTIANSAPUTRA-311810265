<?php
include"koneksi.php";


$query = "DELETE FROM dokumen
							WHERE id ='$_POST[id]'
								";

mysqli_query($koneksi, $query)
or die ("Gagal Perintah SQL".mysql_error());

?>

