<?php
 
session_start();
 
if (empty($_SESSION['username'])){
 
    header('location:login.php');
}
else
{
?>

<!DOCTYPE html>
<html>
<head>
	<title>Kelompok</title>
	<?php include 'template/css.php';?>
</head>
<body>

<?php
	include"koneksi.php";
	$no = 1;
	$data = mysqli_query ($koneksi, " select 
											id_produk,
											nama_produk,
											harga_produk,
											kemasan_produk
											
									  from 
									  produk
									  where id_produk = $_GET[id]");
	$row = mysqli_fetch_array ($data);
	
?>

<div class="container" style="margin-top:2%">
	<div class="row">
                            <div class="sparkline12-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-5 col-sm-5 col-xs-5">
                                            <div class="all-form-element-inner">
                                               	 
			<form class="form-horizontal" action="b_update.php" method="post">

				<div class="box-body">
					<div class="form-group">
						<label for="inputEmail3" class="col-sm-3 control-label">Id Produk</label>
						 <input type="hidden" name="id_produk" value="<?php echo $row['id_produk'] ; ?>">
						<div class="col-sm-4">
							<input type="text" name="id_produk" class="form-control"  value="<?php echo $row['id_produk'] ; ?>" >
						</div>
					</div>

					<div class="form-group">
						<label for="inputPassword3" class="col-sm-3 control-label">Nama Produk</label>

						<div class="col-sm-4">
							<input type="text" name="nama_produk" class="form-control" id="inputPassword3" placeholder="Nama Produk"  value="<?php echo $row['nama_produk'] ; ?>">
						</div>
					</div>


					<div class="form-group">
						<label for="inputPassword3" class="col-sm-3 control-label">Harga Produk</label>

						<div class="col-sm-4">
							<input type="text" name="harga_produk" class="form-control" id="inputPassword3" placeholder="Harga Produk"  value="<?php echo $row['harga_produk'] ; ?>">
						</div>
					</div>


					<div class="form-group">
						<label for="inputPassword3" class="col-sm-3 control-label">Kemasan Produk</label>

						<div class="col-sm-4">
							<input type="text" name="kemasan_produk" class="form-control" id="inputPassword3" placeholder="Kemasan Produk"  value="<?php echo $row['kemasan_produk'] ; ?>">
						</div>
					</div>
					

					</div>
				</div>
				<div class="form-group-inner">
                <div class="login-btn-inner">
                        <div class="row">

                                <div class="col-lg-3"></div>
                                     <div class="col-lg-9">

                                             <div class="login-horizental cancel-wp pull-left form-bc-ele">      

                                                     <button class="btn btn-sm btn-primary login-submit-cs" type="submit">Simpan</button>
                                              </div>
                                            
                                        </div>
                                </div>

                        </div>
                        </div>
				
			</form>
		</div>
	</div>
<?php
}
?>
</body>
</html>



           








