
<!DOCTYPE html>
<html>
<head>
	<title>Kelompok</title>
	<?php include 'template/css.php';?>
</head>
<body>
<div class="container" style="margin-top:2%">
	<div class="row">

	
<div class="col-md-12 col-md-offset-1">
  <div class="data-table-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline13-list">
                            <div class="sparkline13-hd">
                                <div class="main-sparkline13-hd">
                                  
                                    <a  target="_blank" class="btn btn-success" href="export_excel.php"><i class="fa fa-book">Export</a></i>
                                </div>
                            </div>
                            
                            <div class="sparkline13-graph">

                                <div class="datatable-dashv1-list custom-datatable-overright">
								
								<table id="table" data-toggle="table" data-pagination="true" data-search="true"  data-click-to-select="true" data-toolbar="#toolbar">
                                        <thead>
                                            <tr>
                                             
                                                <th data-field="id">No</th>
                                                <th data-field="nama_pelanggan" >Nama Pelanggan</th>
                                                <th data-field="alamat_pelanggan" >Alamat</th>
                                                <th data-field="nama_produk" >Nama Produk</th>
                                                <th data-field="harga_produk" >Harga Produk</th>
                                                <th data-field="nomor_transaksi" >Nomor Transaksi</th>
                                                <th data-field="tanggal_transaksi" >Tanggal Transaksi</th>
                                       
                                     
                                            </tr>

                                            </thead>
                                        <tbody>

                         <?php
            include"koneksi.php";
            $no = 1;
            $data = mysqli_query ($koneksi, " select 
                             p.id_pelanggan,
                             p.nama_pelanggan,
                             p.alamat_pelanggan,

                             b.id_produk,
                             b.nama_produk,
                             b.harga_produk,

                            c.id_transaksi,
                            c.id_pelanggan,
                            c.id_produk,
                             c.nomor_transaksi,
                             c.tanggal_transaksi
                    
                            from pelanggan p INNER JOIN transaksi c ON p.id_pelanggan=c.id_pelanggan
                            inner join produk b on c.id_produk=b.id_produk
                            order by c.id_transaksi DESC ");
            while ($row = mysqli_fetch_array ($data))
            {
              ?>

                                        
                                            <tr>
                                               
                                         <td><?php echo $no++; ?></td>  
                                         <td><?php echo $row['nama_pelanggan']; ?></td>
                                         <td><?php echo $row['alamat_pelanggan']; ?></td>
                                         <td><?php echo $row['nama_produk']; ?></td>
                                         <td><?php echo $row['harga_produk']; ?></td>
                                         <td><?php echo $row['nomor_transaksi']; ?></td>
                                         <td><?php echo $row['tanggal_transaksi']; ?></td>


                                      
                                       
                                            </tr>
                              
                                           
                              
                                      
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>



<?php
}
?>

</table>

<?php include 'template/js.php';?>
</body>
</html>

