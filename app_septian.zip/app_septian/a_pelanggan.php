<?php
include"koneksi.php";

$nama_pelanggan = $_POST['nama_pelanggan'];
$alamat_pelanggan = $_POST['alamat_pelanggan'];
$nohp = $_POST['nohp'];
$status = $_POST['status'];
$nik = $_POST['nik'];


$query = "insert INTO pelanggan SET
								nama_pelanggan = '$nama_pelanggan',
								alamat_pelanggan = '$alamat_pelanggan',
								nohp = '$nohp',
								status = '$status',
								nik = '$nik'
								";

mysqli_query($koneksi, $query)
or die ("Gagal Perintah SQL".mysql_error());
header('location:data_pelanggan.php');
	
?>

