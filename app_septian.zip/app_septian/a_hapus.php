<?php
include"koneksi.php";


$query = "DELETE FROM pelanggan
							WHERE id_pelanggan ='$_GET[id]'
								";

mysqli_query($koneksi, $query)
or die ("Gagal Perintah SQL".mysql_error());
header('location:data_pelanggan.php');

?>

