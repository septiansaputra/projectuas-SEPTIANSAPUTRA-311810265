<?php
include"koneksi.php";
$id_produk = $_POST['id_produk'];
$nama_produk = $_POST['nama_produk'];
$harga_produk = $_POST['harga_produk'];
$kemasan_produk = $_POST['kemasan_produk'];



$query = "UPDATE produk SET
								id_produk = '$id_produk',
								nama_produk = '$nama_produk',
								harga_produk = '$harga_produk',
								kemasan_produk = '$kemasan_produk'

						
								WHERE id_produk = '$id_produk'
								";

mysqli_query($koneksi, $query)
or die ("Gagal Perintah SQL".mysql_error());
header('location:data_produk.php');

?>

