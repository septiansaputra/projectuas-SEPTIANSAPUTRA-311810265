

<!DOCTYPE html>
<html>
<head>
	<title>Produk</title>
	<?php include 'template/css.php';?>
</head>
<body>
	
<div class="container" style="margin-top:2%">
	<div class="row">
                            <div class="sparkline12-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-5 col-sm-5 col-xs-5">
                                            <div class="all-form-element-inner">
                                               	 
			<form class="form-horizontal" action="a_produk.php" method="post">
				<div class="box-body">
					<div class="form-group">
						<label for="inputEmail3" class="col-sm-3 control-label">Nama Produk</label>

						<div class="col-sm-4">
							<input type="text" name="nama_produk" class="form-control" placeholder="Nama Produk" autofocus>
						</div>
					</div>

					<div class="form-group">
						<label for="inputPassword3" class="col-sm-3 control-label">Harga Produk</label>

						<div class="col-sm-4">
							<input type="text" name="harga_produk" class="form-control" id="inputPassword3" placeholder="Harga Produk">
						</div>
					</div>


					<div class="form-group">
						<label for="text" class="col-sm-3 control-label">Kemasan Produk</label>

						<div class="col-sm-4">
							<input type="text" name="kemasan_produk" class="form-control" placeholder="kemasan produk" autofocus>
						</div>
					</div>
					
				

				</div>


				<div class="form-group-inner">
                <div class="login-btn-inner">
                        <div class="row">


                                <div class="col-lg-3">
                                	
                                </div>

                                     <div class="col-lg-9">

                                             <div class="login-horizental cancel-wp pull-left form-bc-ele">      
                                                     <button class="btn btn-sm btn-primary login-submit-cs" type="submit">Simpan</button>
                                              </div>
                                            
                                        </div>
                                </div>


                               

                        </div>
                        </div>
				
			</form>
		</div>
	</div>

</body>
</html>



           