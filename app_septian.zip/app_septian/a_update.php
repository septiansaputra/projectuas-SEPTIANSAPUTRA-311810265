<?php
include"koneksi.php";
$id_pelanggan = $_POST['id_pelanggan'];
$nama_pelanggan = $_POST['nama_pelanggan'];
$alamat_pelanggan = $_POST['alamat_pelanggan'];
$nohp = $_POST['nohp'];
$status = $_POST['status'];
$nik = $_POST['nik'];



$query = "UPDATE pelanggan SET
								id_pelanggan = '$id_pelanggan',
								nama_pelanggan = '$nama_pelanggan',
								alamat_pelanggan = '$alamat_pelanggan',
								nohp = '$nohp',
								status = '$status',
								nik = '$nik'
							
						
								WHERE id_pelanggan = '$id_pelanggan'
								";

mysqli_query($koneksi, $query)
or die ("Gagal Perintah SQL".mysql_error());
header('location:data_pelanggan.php');

?>

